@echo off
title GLAD - Laser Epilation Studio

echo.
echo ========================================
echo    GLAD - Laser Epilation Studio
echo ========================================
echo.

where node >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is not installed!
    echo.
    echo 1. Download Node.js from https://nodejs.org/
    echo 2. Install LTS version
    echo 3. Run this file again
    echo.
    pause
    exit /b 1
)

where npm >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] npm is not installed!
    echo Install Node.js from https://nodejs.org/
    pause
    exit /b 1
)

echo [OK] Node.js installed:
node -v
echo.

if not exist "node_modules" (
    echo [INSTALL] Installing dependencies...
    echo This may take a few minutes...
    echo.
    call npm install
    if %errorlevel% neq 0 (
        echo.
        echo [ERROR] Failed to install dependencies
        pause
        exit /b 1
    )
    echo.
    echo [OK] Dependencies installed!
    echo.
)

echo ========================================
echo    STARTING SERVER
echo ========================================
echo.
echo Site will open in browser automatically
echo URL: http://localhost:3000
echo.
echo Press Ctrl+C to stop
echo ========================================
echo.

start "" cmd /c "timeout /t 3 /nobreak >nul && start http://localhost:3000"

call npm run dev

pause
